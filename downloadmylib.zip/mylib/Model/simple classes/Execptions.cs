﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class FileNotFoundException : Exception

    {
        public FileNotFoundException() { }
        public FileNotFoundException(string message) : base(message) { 
        
        }


    }

    public class BuyingTooManyItemsException : Exception
    {
        public BuyingTooManyItemsException() { }
        public BuyingTooManyItemsException(string message) : base(message)
        {

        }
    }




}
