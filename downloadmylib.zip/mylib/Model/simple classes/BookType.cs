﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public enum BookType
    {
        undefined, adventure, mystery, science, bio

    }
}
