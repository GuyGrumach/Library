﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Journal : AbstractItem 
    {

        public JournalType JournalType { get; set; }

        public Journal(string name, string authorName, DateTime publishDate, string summary, int amount,
            int edition,  int price, string pictureUrl, int maxDiscount, JournalType journalType) :
            base(name, authorName, publishDate, summary, amount, edition, price, pictureUrl, maxDiscount,0)
        {

            this.JournalType = journalType;

        }
    }
}
