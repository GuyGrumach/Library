﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;


namespace Model
{
    public class Discount 
    {
        public int AmountOfDiscount { get; set; }
        public DiscountType DiscountType { get; set; }
        public string NameOfDiscount { get; set; }




        public Discount(int amount, DiscountType discountType,string name)
        {
            AmountOfDiscount = amount;
            DiscountType = discountType;
            NameOfDiscount = name;
        }

        public override string ToString()
        {
            return $"discount of : {AmountOfDiscount}% ,Type : {DiscountType} ,name : {NameOfDiscount}";


        }
    }
}
