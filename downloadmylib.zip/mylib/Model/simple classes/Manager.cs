﻿using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModel;
using Windows.Storage;

namespace Model
{
    public class Manager : IList<AbstractItem>
    {

    //    public FileTextManager errSave = new FileTextManager("exceptionSave.txt");
        public ObservableCollection<AbstractItem> Items { get; set; } 
        private FileHandling<AbstractItem> fileHandling { get; set; } = new FileHandling<AbstractItem>("myLibrary.json");





        private static Manager instance = null;
        public static Manager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Manager();
                }
                return instance;
            }
        }
        private Manager()
        {

            List<AbstractItem> items = fileHandling.Deserialize();
            Items = new ObservableCollection<AbstractItem>(items); 
            
        }

        //conditions to filter and sort
        public List<AbstractItem> SearchBy(Predicate<AbstractItem> predicate) => Items.ToList<AbstractItem>().FindAll(predicate);
        public void SortBy(Comparison<AbstractItem> comparison)
        {
            List<AbstractItem> list = Items.ToList<AbstractItem>();
            list.Sort(comparison);
            foreach (var item in list)
            {
                Items.Remove(item);

            }

            for (int i = 0; i < list.Count; i++)
            {
                Items.Add(list[i]);

            }

            

            
        }


        //reset values
        public void ChangeDiscountToZero(Discount discount)
        {
            for (int i = 0; i < Items.Count; i++)
            {
                if (Items[i].AuthorName == discount.NameOfDiscount &&  discount.DiscountType == DiscountType.AuthorName)
                {
                    Items[i].MaxDiscount = 0;
                }
            }
        }

        public int findItemIndex(AbstractItem abstractItem)
        {
            Book b = abstractItem as Book;

            if (b != null)
            {
                return (int)b.bookType;
                
            }
            else
            {
                Journal journal = (Journal)abstractItem;
                return (int)journal.JournalType;

            }

        }

        public void UpdateDiscounts()
        {
            DiscountManager.Instance.updateDiscounts();
        }

















        public AbstractItem this[int index] { get => null; set => throw new Exception(); }

        public void Serialize() => fileHandling.Serialize(Items.ToList<AbstractItem>());

        public int Count => throw new NotImplementedException();

        public bool IsReadOnly => throw new NotImplementedException();

        public void Add(AbstractItem item) => Items.Add(item); 


        public void Clear()
        {

        }

        public bool Contains(AbstractItem item)
        {
            return Items.Contains(item);
        }

        public void CopyTo(AbstractItem[] array, int arrayIndex)
        {

        }

        public IEnumerator<AbstractItem> GetEnumerator()
        {
            return null;

        }

        public int IndexOf(AbstractItem item)
        {
            return 0;
        }

        public void Insert(int index, AbstractItem item)
        {

        }

        public bool Remove(AbstractItem item)
        {
            if(item != null)
            {
                Items.Remove(item);
                Serialize();
                return true;

            }

            return false;
        }

        public void RemoveAt(int index)
        {

        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return null;
        }
    }
}







