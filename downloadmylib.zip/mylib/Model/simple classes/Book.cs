﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;

namespace Model
{
    public class Book : AbstractItem
    {

        public BookType bookType { get; set; }


        public Book(string name, string authorName, DateTime publishDate, string summary, int amount,
            int edition, int price, string pictureUrl, int maxDiscount, BookType bookType) :
            base(name, authorName, publishDate, summary, amount, edition, price, pictureUrl, maxDiscount,0)
        {

            this.bookType = bookType;


        }

    }
}
