﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Purchase
    {
        public int Amount { get; set; }
        public string  Name { get; set; }
        public string Author { get; set; }
        public DateTime PurchaseTime { get; set; }

        public Purchase(int amount, string name, string author, DateTime purchaseTime)
        {
            Amount = amount;
            Name = name;
            Author = author;
            PurchaseTime = purchaseTime;
        }

        public override string ToString()
        {
            return $"Name : {Name} , Author : {Author} , Date : {PurchaseTime.ToString()}";
        }


    }
}
