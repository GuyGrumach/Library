﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;

namespace Model
{
    public abstract class AbstractItem
    {

        public string Name { get; set; }

        public string AuthorName { get; set; }

        public DateTime PublishDate { get; set; }

        public int Price { get; set; }

        public string Summary { get; set; }

        public int AmountInStock { get; set; }

        public int MaxDiscount { get; set; }

        public int Edition { get; set; }

        public int AmountToBuy { get; set; }

        public string PictureUrl { get; set; }



        public AbstractItem(string name, string authorName, DateTime publishDate, string summary, int amount, int edition, int price, string pictureUrl, int maxDiscount, int amountToBuy)
        {

            Name = name;
            PublishDate = publishDate;
            Summary = summary;
            AmountInStock = amount;
            Edition = edition;
            AuthorName = authorName;
            this.Price = price;
            PictureUrl = pictureUrl;
            MaxDiscount = maxDiscount;
            AmountToBuy = amountToBuy;
            
        }



        public override string ToString()
        {
            return $"book name : {Name} \nauthor name : {AuthorName} \npublish date : {PublishDate.ToString()} \namount in stock : {AmountInStock}" +
                $"\nprice with discount : {getPriceAfterDiscount()} \nsummary : {Summary}";
        }

        
        public int getPriceAfterDiscount()
        {
            double precentMulty = (100 - MaxDiscount) / 100.0;
            return MaxDiscount != 0 ? (int)(precentMulty * Price) : Price;
        }


    }
}
