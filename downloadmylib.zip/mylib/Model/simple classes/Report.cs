﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Report
    {

        public string  str { get; set; }
        public Report(string str)
        {
            this.str = str;
        }


        public override string ToString()
        {
            return str;
        }
    }
}
