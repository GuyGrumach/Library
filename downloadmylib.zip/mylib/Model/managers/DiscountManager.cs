﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModel;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace Model
{
    public class DiscountManager : IList<Discount> 
    {
        private FileHandling<Discount> fileHandling; 
        public ObservableCollection<Discount> discountList { get; set; } = new ObservableCollection<Discount>();





        //signletone implementattion for having only one instance with list 
        private static DiscountManager instance = null ;
        public static DiscountManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DiscountManager();
                }
                return instance;
            }
        }
        private DiscountManager()
        {
            //initiallise obj
            fileHandling = new FileHandling<Discount>("discounts.json");
            List<Discount> discounts = fileHandling.Deserialize();
            if (discounts != null)
            {
                //casting
                ObservableCollection<Discount> collection = new ObservableCollection<Discount>(discounts);
                discountList = collection;
            }

            updateDiscounts();

        }
        //save list
        public void Serialize()
        {
            fileHandling.Serialize(discountList.ToList<Discount>());

        }
        //add and update
        public void Add(Discount item)
        {
            discountList.Add(item);
            updateDiscounts();

        }

        public void updateDiscounts()
        {
            foreach (var discount in discountList) //gets all discounts
            {
                foreach (var item in Manager.Instance.Items) //get all items
                {
                    if (discount.DiscountType == DiscountType.AuthorName) //update item by author discount
                    {
                        if (item.AuthorName == discount.NameOfDiscount)
                        {
                            item.MaxDiscount = discount.AmountOfDiscount > item.MaxDiscount ? discount.AmountOfDiscount : item.MaxDiscount;
                        }
                    }
                    else // here implementation to if its an enum value
                    {
                        if (item.GetType() == typeof(Book)){//check for type and max 
                            if (((Book)item).bookType.ToString() == discount.NameOfDiscount)
                            {
                                item.MaxDiscount = discount.AmountOfDiscount > item.MaxDiscount ? discount.AmountOfDiscount : item.MaxDiscount;
                            }
                        }
                        else
                        {
                            if (((Journal)item).JournalType.ToString() == discount.NameOfDiscount)
                            {
                                item.MaxDiscount = discount.AmountOfDiscount > item.MaxDiscount ? discount.AmountOfDiscount : item.MaxDiscount;
                            }

                        }
                    }
                }

            }
            Manager.Instance.Serialize();

        }




















        //all iList Method implementation for oop right desing , havent have time to implement it

        public int Count => throw new NotImplementedException();

        public bool IsReadOnly => throw new NotImplementedException();

        public Discount this[int index] { get => null; set => throw new Exception(); }


        public int IndexOf(Discount item)
        {
            return -1;

        }

        public void Insert(int index, Discount item)
        {

        }

        public void RemoveAt(int index)
        {

        }


        public void Clear()
        {

        }

        public bool Contains(Discount item)
        {
            return false;

        }

        public void CopyTo(Discount[] array, int arrayIndex)
        {

        }

        public bool Remove(Discount item)
        {
            if(item != null)
            {
                Manager.Instance.ChangeDiscountToZero(item);
                discountList.Remove(item);
                updateDiscounts();
                Serialize();
                return true;
            }
            return false;
        }

        public IEnumerator<Discount> GetEnumerator()
        {
            return null;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return null;

        }
    }
}
