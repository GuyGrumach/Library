﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using ViewModel;

namespace Model
{
    public class ReportManager : IList<Report>
    {

        //properties and fields
        public ObservableCollection<Report> Reports { get; set; } = new ObservableCollection<Report>();

        private FileHandling<Report> fileHandling = new FileHandling<Report>("reports.json");

        private static ReportManager instance = null;
        public static ReportManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ReportManager();
                }
                return instance;
            }
        }
        private ReportManager()
        {


        }

        //next methods are logic and produce reports
        public void generateReportFirstOption(DatePicker startDatePicker, DatePicker endDatePicker)
        {
            DateTime start = startDatePicker.SelectedDate.Value.DateTime;
            DateTime end = endDatePicker.SelectedDate.Value.DateTime;
            Reports.Add(new Report("First option report :"));
            foreach (var item in PurchaseManager.Instance.itemsBougthBefore)
            {
               if(item.PurchaseTime.CompareTo(start) >= 1 && item.PurchaseTime.CompareTo(end) <= 1)
                {
                        Reports.Add(new Report(item.ToString()));                   
                }
            }

            fileHandling.Serialize(Reports.ToList());


        }

        public void generateReportSecondOption(TextBox tBAuthorName)
        {
            Reports.Clear();
            foreach (var item in Manager.Instance.Items)
            {
                if (item.AuthorName == tBAuthorName.Text)
                {
                    Reports.Add(new Report(item.ToString()));
                }
            }

            fileHandling.Serialize(Reports.ToList());


            //write to file


        }

        public void generateReportThirdOption(DatePicker datePickerYear)
        {

            Reports.Clear();
            foreach (var item in Manager.Instance.Items)
            {
                if (item.PublishDate.CompareTo(datePickerYear.SelectedDate.Value.DateTime) > -1)
                {
                    Reports.Add(new Report(item.ToString()));
                }
            }

            fileHandling.Serialize(Reports.ToList());



        }






        //ilist implementation no time to actually implement , better oop design

        public Report this[int index] { get => null; set => throw new Exception(); }

        public int Count => throw new NotImplementedException();

        public bool IsReadOnly => throw new NotImplementedException();

        public void Add(Report item)
        {

        }

        public void Clear()
        {
            Reports.Clear();

        }

        public bool Contains(Report item)
        {
            return false;
        }

        public void CopyTo(Report[] array, int arrayIndex)
        {
        }

        public IEnumerator<Report> GetEnumerator()
        {
            return null;
        }

        public int IndexOf(Report item)
        {
            return 0;
        }


        public void Insert(int index, Report item)
        {
            throw new NotImplementedException();
        }

        public bool Remove(Report item)
        {
            throw new NotImplementedException();
        }

        public void RemoveAt(int index)
        {
            throw new NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return "1";
        }


    }
}
