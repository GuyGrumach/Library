﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Model;
using ViewModel;

namespace Model
{
    public  class PurchaseManager
    {
        //properties
        public List<AbstractItem> Items { get; set; }
        public List<Purchase> itemsBougthNow { get; set; } = new List<Purchase>();
        public List<Purchase> itemsBougthBefore { get; set; }
        //field
        private FileHandling<Purchase> purchasesFileOperation = new FileHandling<Purchase>("purchases.json");



        //singletone pattern
        private static PurchaseManager instance = null;
        public static PurchaseManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new PurchaseManager();
                }
                return instance;
            }
        }
        private PurchaseManager()
        {

            itemsBougthBefore = purchasesFileOperation.Deserialize();
        }





        //purchase logic
        public async void purchase(List<AbstractItem> items)
        {
            StringBuilder st = new StringBuilder();
            st.Append("Going to execute buy of : \n");
            int numOfDollars = 0;
            foreach (var item in items)
            {
                int amountPossibleTobuy = item.AmountToBuy > item.AmountInStock ? item.AmountInStock : item.AmountToBuy;
                st.Append("Name : " + item.Name + " and the amount of is " + amountPossibleTobuy + "\n");
                numOfDollars += item.getPriceAfterDiscount() * amountPossibleTobuy;

            }
            st.Append($"OverAll money {numOfDollars.ToString()}$\n");
            st.Append("\n if amount is smaller than asked for it means we dont have enough books\n");
            st.Append("\n Are you sure ?");
            var messageDialog = new MessageDialog(st.ToString());

            messageDialog.Commands.Add(new UICommand(
                "yes",
                new UICommandInvokedHandler(this.CommandInvokedHandler)));
            messageDialog.Commands.Add(new UICommand(
                "no",
                new UICommandInvokedHandler(this.CommandInvokedHandler)));

            messageDialog.DefaultCommandIndex = 0;

            // Set the command to be invoked when escape is pressed
            messageDialog.CancelCommandIndex = 1;

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        private void CommandInvokedHandler(IUICommand command)
        {
            if (command.Label == "yes")
            {
                try
                {
                    executePurchase();
                }
                catch (BuyingTooManyItemsException e)
                {
                    WritingExceptionToTxtFile.WriteToFile(e);
                }
            }
            
        }

        //execute purchase methodology , can buy few items together
        private void executePurchase()
        {
            StringBuilder sb = new StringBuilder();


            if (Items != null)
            {
                for (int i = 0; i < Items.Count; i++)
                {
                    //checking how much can buy
                    int amountPossibleTobuy = Items[i].AmountToBuy > Items[i].AmountInStock ? Items[i].AmountInStock : Items[i].AmountInStock;
                    Items[i].AmountInStock -= amountPossibleTobuy;
                    if(Items[i].AmountInStock == 0)
                    {
                        //new purchase
                        itemsBougthNow.Add(new Purchase(amountPossibleTobuy, Items[i].Name, Items[i].AuthorName, DateTime.Now));
                        Manager.Instance.Remove(Items[i]);
                        if(Items[i].AmountToBuy > Items[i].AmountInStock)
                        {
                            sb.Append($"missing {Items[i].AmountToBuy - Items[i].AmountInStock} of the book ");
                            sb.Append($"{Items[i].Name} by {Items[i].AuthorName} \n");
                        }
                    }
                }
                writeToFilePurchases();
                if(sb.ToString() != "")
                {
                    throw new BuyingTooManyItemsException(sb.ToString());
                }
                
                
            }
        }


        private void writeToFilePurchases()
        {
            itemsBougthBefore.AddRange(itemsBougthNow);
            purchasesFileOperation.Serialize(itemsBougthBefore);
            itemsBougthNow.Clear();

        }
    }
}
