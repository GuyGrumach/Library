﻿

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238
using System;
using System.Collections.Generic;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media.Imaging;
using ViewModel;
using Model;
using Windows.UI.Xaml.Navigation;

namespace MyLibrary
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class AddPage : Page
    {
        //for validation methodology

        List<TextBox> textBoxesText = new List<TextBox>();
        List<TextBox> textBoxesNum = new List<TextBox>();
        string url = "";
        AbstractItem currentItem;


        
        public AddPage()
        {
            this.InitializeComponent();

        }

        private void initWithValues()
        {
            addBtn.Content = "Update";
            TBNameOfPage.Text = "Update item Page";
            TBName.Text = currentItem.Name;
            TBAuthorName.Text = currentItem.AuthorName;
            TBPrice.Text = currentItem.Price.ToString();
            TBSummary.Text = currentItem.Summary.ToString();
            TBEdition.Text = currentItem.Edition.ToString();
            url = currentItem.PictureUrl;
            TBAmount.Text = currentItem.AmountInStock.ToString();
            PublishDate.Date = currentItem.PublishDate;
            if(currentItem is Book)
            {
                Book book = (Book)currentItem;
                ComboBoxType.SelectedIndex = 1;
                ComboBoxTypeValues.SelectedIndex = Manager.Instance.findItemIndex(currentItem);
            }
            else
            {
                Journal journal = (Journal)currentItem;
                ComboBoxType.SelectedIndex = 0;
                ComboBoxTypeValues.SelectedIndex = Manager.Instance.findItemIndex(currentItem);

            }





        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            //base.OnNavigatedFrom(e);
            currentItem = e.Parameter as AbstractItem;
            if (currentItem == null)
            {
                init();
            }
            else
            {
                initWithValues();
            }

        }


        //init the page while making order
        private void init()
        {
            addBtn.Content = "Add";
            TBNameOfPage.Text = "Add item Page";
            textBoxesText.Add(TBName);
            textBoxesText.Add(TBAuthorName);
            textBoxesText.Add(TBSummary);
            textBoxesNum.Add(TBPrice);
            textBoxesNum.Add(TBAmount);
            textBoxesNum.Add(TBEdition);
            ComboBoxTypeValues.Visibility = Visibility.Collapsed;
        }


        //get image adress
        private async void ImageBtn_Click_1(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail;
            picker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.PicturesLibrary;
            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");

            Windows.Storage.StorageFile file = await picker.PickSingleFileAsync();
            if (file != null)
            {
                url = file.Path;


            }
            else
            {
                _=new MessageDialog("problem").ShowAsync(); 
            }

        }




        //validating fields are filed and valid then adding to repository

        //need to update it againnnnnnnnnn @21394894w98q7489239
        private void addBtn_Click(object sender, RoutedEventArgs e)
        {

            if (CheckIfAllValid())
            {
                if (currentItem != null)
                {
                    Manager.Instance.Remove(currentItem);
                }

                if (ComboBoxType.SelectionBoxItem.ToString() == "Book")
                {
                    Book book = new Book(TBName.Text, TBAuthorName.Text, PublishDate.SelectedDate.Value.DateTime, TBSummary.Text,
                                            int.Parse(TBAmount.Text), int.Parse(TBEdition.Text), int.Parse(TBPrice.Text), url, 0, (BookType)ComboBoxTypeValues.SelectedItem);
                    Manager.Instance.Add(book);
                }
                else
                {

                    Journal journal = new Journal(TBName.Text, TBAuthorName.Text, PublishDate.SelectedDate.Value.DateTime, TBSummary.Text,
                        int.Parse(TBAmount.Text), int.Parse(TBEdition.Text), int.Parse(TBPrice.Text), url, 0, (JournalType)ComboBoxTypeValues.SelectedItem);
                    Manager.Instance.Add(journal);


                }
                _ = new MessageDialog("item was added/updated").ShowAsync();

                Manager.Instance.Serialize();


            }

            if (currentItem != null) Frame.Navigate(typeof(StorePage));
            reset();
        }


        //check validation
        private bool CheckIfAllValid()
        {
            if (Validate.validateAllValuesFilled(textBoxesText))
            {
                if (Validate.ValidateAllNumAndFilles(textBoxesNum))
                {
                    if (PublishDate.SelectedDate != null && ComboBoxType.SelectedItem != null && url != "")
                    {
                        return true;
                    }
                }
            }
            _= new MessageDialog("USTON WE HAVE A PROBLEM WITH NO TEXT BOX").ShowAsync();
            return false;
        }




        private void resetBtn_Click(object sender, RoutedEventArgs e)
        {
            reset();

        }



        //reset all uielements
        private void reset()
        {
            List<TextBox> TextBoxes = new List<TextBox>();
            TextBoxes.AddRange(textBoxesNum);
            TextBoxes.AddRange(textBoxesText);
            foreach (var item in TextBoxes)
            {
                item.Text = "";
            }
            PublishDate.SelectedDate = null;
            ComboBoxType.Text = "";
            ComboBoxTypeValues.Visibility = Visibility.Collapsed;
            url = "";
                  
        }



        //event to choose what to show
        private void ComboBoxType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            ComboBoxTypeValues.Visibility = Visibility.Visible;
            string Text = ((ComboBoxItem)ComboBoxType.SelectedItem).Content.ToString();

            if (Text == "Book")
            {
               ComboBoxTypeValues.ItemsSource = Enum.GetValues(typeof(BookType));
            }
            else if(Text == "Journal")
            {
                ComboBoxTypeValues.ItemsSource = Enum.GetValues(typeof(JournalType));

            }

        }
    }
}
