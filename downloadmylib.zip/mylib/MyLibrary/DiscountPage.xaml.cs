﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Model;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MyLibrary 
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class DiscountPage : Page
    {


        DiscountManager discountManager = DiscountManager.Instance;


        public DiscountPage()
        {
            this.InitializeComponent();
            init();
        }

        //init text box for amount of discount
        private void init()
        {
            reset();
            for (int i = 1; i < 100; i++)
            {
                ComboBoxDisountAmount.Items.Add(i);

            }

        }


        //showing relative uiElements
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            reset();
            ComboBoxItem item = (ComboBoxItem)((ComboBox)sender).SelectedItem;
            if(item.Content != null)
            {
                if (item.Content.ToString() == "Author") StackPanelName.Visibility = Visibility.Visible;
                else
                {
                    StackPanelType.Visibility = Visibility.Visible;
                    if(item.Content.ToString() == "Book")
                    {
                        var _enumval = Enum.GetValues(typeof(BookType)).Cast<BookType>();
                        comboBoxEnum.ItemsSource = _enumval.ToList();
                    }
                    else
                    {
                        var _enumval = Enum.GetValues(typeof(JournalType)).Cast<JournalType>();
                        comboBoxEnum.ItemsSource = _enumval.ToList();
                    }
                }
            }           
        }

        //reset ui elements
        private void reset()
        {
            StackPanelName.Visibility = Visibility.Collapsed;
            StackPanelType.Visibility = Visibility.Collapsed;
            StackPanelDiscount.Visibility = Visibility.Collapsed;



        }


        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            StackPanelDiscount.Visibility = Visibility.Visible;

        }

        //adding logic and instintiate the right discount 
        private void addBtn_Click(object sender, RoutedEventArgs e)
        {
            DiscountType currentDiscountType = ComboBoxDiscountType.SelectionBoxItem == "Author" ? DiscountType.AuthorName : DiscountType.Genre;
            string nameOfDiscount = currentDiscountType == DiscountType.AuthorName ? TBName.Text : comboBoxEnum.SelectionBoxItem.ToString() ;
            Discount discount = new Discount(int.Parse(ComboBoxDisountAmount.SelectedItem.ToString()), currentDiscountType, nameOfDiscount);
            discountManager.Add(discount);
            discountManager.Serialize();
            reset(); 
        }


        private void removeBtn_Click(object sender, RoutedEventArgs e)
        {
            Discount discount = ((Discount)DiscountsListView.SelectedItem);
            discountManager.Remove(discount);

        }

        private void comboBoxEnum_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StackPanelDiscount.Visibility = Visibility.Visible;

        }
    }
}
