﻿using Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MyLibrary
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ReportPage : Page
    {

        int index = 0;
        ReportManager reportManager = ReportManager.Instance;




        public ReportPage()
        {
            this.InitializeComponent();
            init();
        }

        void LayoutRoot_Loaded(object sender, RoutedEventArgs e)
        {
            ReportManager.Instance.Clear();

        }


        private void init()
        {
            TBAuthorName.Visibility = Visibility.Collapsed;
            StackPanelTime.Visibility = Visibility.Collapsed;
            StackPanelTimeFrom.Visibility = Visibility.Collapsed;
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            init();
            string option = ((ComboBoxItem)ComboBoxOptions.SelectedItem).Content.ToString();
            switch (option)
            {
                case "Report on purchase between dates":
                    StackPanelTime.Visibility = Visibility.Visible;
                    index = 1;
                    break;
                case "Report on book by author":
                    TBAuthorName.Visibility = Visibility.Visible;
                    index = 2;
                    break;
                case "Report on book of certain yaer":
                    StackPanelTimeFrom.Visibility = Visibility.Visible;
                    index = 3;
                    break;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            switch (index)
            {

                case 1:
                    reportManager.generateReportFirstOption(startDatePicker,endDatePicker);

                    break;

                case 2:
                    reportManager.generateReportSecondOption(TBAuthorName);


                    break;

                case 3:
                    reportManager.generateReportThirdOption(DatePickerYear);


                    break;
            } 
                                               

        }

    }
}
