﻿using System.Collections.Generic;
using System.Linq;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Model;
using System.Drawing;
using Windows.UI;
using Windows.UI.Xaml.Media;
using FontFamily = Windows.UI.Xaml.Media.FontFamily;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MyLibrary
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class StorePage : Page
    {
        
        


        public StorePage()
        {
            this.InitializeComponent();
            init();

        }


        private void init()
        {


        }

        private void minusBtn_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            if (((AbstractItem)b.DataContext).AmountToBuy -1 >= 0)
            {
                ((AbstractItem)b.DataContext).AmountToBuy--;
                StackPanel stackPanel = (StackPanel)b.Parent;
                UIElementCollection ui = stackPanel.Children;
                ((TextBlock)ui[1]).Text = ((AbstractItem)b.DataContext).AmountToBuy.ToString();


            }

/*            ((AbstractItem)b.DataContext).AmountToBuy--;
            StackPanel stackPanel = (StackPanel)b.Parent;
            UIElementCollection ui = stackPanel.Children;
            ((TextBlock)ui[1]).Text = ((AbstractItem)b.DataContext).AmountToBuy.ToString();
*/


        }

        private void plusBtn_Click(object sender, RoutedEventArgs e)
        {
            Button b = sender as Button;
            ((AbstractItem)b.DataContext).AmountToBuy++;
            StackPanel stackPanel = (StackPanel)b.Parent;
            UIElementCollection ui = stackPanel.Children;
            ((TextBlock)ui[1]).Text = ((AbstractItem)b.DataContext).AmountToBuy.ToString();


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<AbstractItem> items =  Manager.Instance.Items.ToList<AbstractItem>();
            List<AbstractItem> abstractItemsToBuy =  items.FindAll((x) => x.AmountToBuy > 0);
            PurchaseManager p = PurchaseManager.Instance;
            p.Items = abstractItemsToBuy;
            p.purchase(abstractItemsToBuy);

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if(myGridView.SelectedItem != null)
            {
                AbstractItem currentItem = myGridView.SelectedItem as AbstractItem;
                Frame.Navigate(typeof(AddPage), currentItem);

            }

        }

        private void myGridView_ItemClick(object sender, ItemClickEventArgs e)
        {
            AbstractItem abstractItem = ((GridViewItem)sender).DataContext as AbstractItem;





        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

            Manager.Instance.SortBy((x, y) => x.AuthorName.CompareTo(y.AuthorName));

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Manager.Instance.SortBy((x, y) => y.MaxDiscount.CompareTo(x.MaxDiscount));

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Manager.Instance.SortBy((x, y) => x.getPriceAfterDiscount().CompareTo(y.getPriceAfterDiscount()));

        }

        private void myGridView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            StackPanelShowAllData.Children.Clear();
            AbstractItem abstractItem = ((GridView)sender).SelectedItem as AbstractItem;
            if(abstractItem != null)
            {
                TextBlock textBlock = new TextBlock();
                textBlock.Text = "\nINFO : \n\n" + abstractItem.ToString();
                textBlock.FontFamily = new FontFamily("times new roman");
                textBlock.FontSize = 22;
                textBlock.Foreground = new SolidColorBrush(Colors.Black); ;
                StackPanelShowAllData.Children.Add(textBlock);

            }


        }
    }
}
