﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Popups;
using Windows.UI.Xaml.Controls;

namespace ViewModel
{
    public static class Validate
    {



        public static bool validateAllValuesFilled(List<TextBox> textBoxText)
        {
            foreach (TextBox textBox in textBoxText)
            {
                if (string.IsNullOrEmpty(textBox.Text))
                {
                    new MessageDialog($"we have a problem with {textBox.Name}").ShowAsync();
                    return false;
                }

            }

            return true;


        }



        public static bool ValidateAllNumAndFilles (List<TextBox> textBoxNum)
        {
            foreach (TextBox textBox in textBoxNum)
            {
                int num;
                if (!Int32.TryParse(textBox.Text, out num))
                {
                    new MessageDialog($"we have a problem with {textBox.Name}").ShowAsync();
                    return false;
                }

            }

            return true;


        }






    }
}
