﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace ViewModel
{
    //writing and reading from file 
    public class FileHandling<T>
    {

        string filePath;
        List<T> _items;
        StorageFolder folder = ApplicationData.Current.LocalFolder;



        public FileHandling(string fileName)
        {
            filePath = folder.Path + "/" + fileName;
            if (!File.Exists(filePath))
            {
                using(FileStream fs = new FileStream(filePath, FileMode.Create)) { }
            }
        }

        public void Serialize(List<T> items)
        {
            JsonSerializerSettings settings = new JsonSerializerSettings();
            settings.TypeNameHandling = TypeNameHandling.Auto;
            settings.NullValueHandling = NullValueHandling.Ignore;
            string data = JsonConvert.SerializeObject(items, Formatting.Indented, settings);
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                sw.WriteLine(data);
            }
        }

        public List<T> Deserialize()
        {
            using (StreamReader sr = new StreamReader(filePath))
            {
                string data = sr.ReadToEnd();

                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.TypeNameHandling = TypeNameHandling.Auto;
                settings.NullValueHandling = NullValueHandling.Ignore;
                return JsonConvert.DeserializeObject<List<T>>(data, settings);
            }


        }
    }
}
