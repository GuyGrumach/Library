﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace ViewModel
{
    public static class WritingExceptionToTxtFile
    {

        static string filePath = ApplicationData.Current.LocalFolder.Path + "/" + "exceptions.txt" ;
        private static StringBuilder sb = new StringBuilder();


        public static void WriteToFile(Exception e)
        {


            try
            {
                checkForFile();
                sb.Append(LoadFromFile()) ;
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    WriteToFileExecute(sw, e);
                }
            }

            catch (FileNotFoundException fileException)
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Create)) { }
                using (StreamWriter sw = new StreamWriter(filePath))
                {
                    WriteToFileExecute(sw, fileException);
                }

            }
        }

        private static string LoadFromFile()
        {
            using (StreamReader sr = new StreamReader(filePath))
            {
                return sr.ReadToEnd();

            }
            

        }

            private static void checkForFile()
        {
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("FileNotFoundException - there is no file to write to in local folder"); 
            }

        }

        private static void WriteToFileExecute( StreamWriter sw , Exception e)
        {
            
            sb.AppendLine(DateTime.Now.ToString());
            sb.Append(e.GetType() + " - ");
            sb.AppendLine(e.Message);
            sb.AppendLine();
            sb.AppendLine("--------------------------------------------------------");
            sw.WriteLine(sb.ToString());
        }

    }
}
